﻿using BindDDLwithModel49.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;
using System.Xml.Linq;

namespace BindDDLwithModel49.Controllers
{
    public class HomeController : Controller
    {
        private readonly EmployeeContext context;

        public HomeController(EmployeeContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            var mydata = BindDDl();
            return View(mydata);
        }

        [HttpPost,ActionName("Index")]
        public IActionResult IndexPost(EmpModel emp)
        {
            var emps = context.EmpTabs.Where(x=>x.Id == emp.Id).FirstOrDefault();
            if (emps != null)
            {
                ViewBag.SelectedValue = emps.EmpName;
                
            }
            var mydata = BindDDl();

            return View(mydata);
        }

        private  EmpModel BindDDl()
        {

            EmpModel empmodel = new EmpModel();
            empmodel.EmpList = new List<SelectListItem>();
            var data = context.EmpTabs.ToList();
            empmodel.EmpList.Add(new SelectListItem
            {
                Text = "select name",
                Value = "",

            });
            foreach (var item in data)
            {
                empmodel.EmpList.Add(new SelectListItem
                {
                    Text = item.EmpName,
                    Value = item.Id.ToString(),

                });
            }
            return empmodel;
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}