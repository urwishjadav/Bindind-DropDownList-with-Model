﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace BindDDLwithModel49.Models
{
    public class EmpModel
    {
        public int Id { get; set; }
        public List<SelectListItem> EmpList { get; set; }
    }
}
