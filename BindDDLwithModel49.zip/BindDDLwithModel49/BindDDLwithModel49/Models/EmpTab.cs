﻿using System;
using System.Collections.Generic;

namespace BindDDLwithModel49.Models
{
    public partial class EmpTab
    {
        public int Id { get; set; }
        public string EmpName { get; set; } = null!;
        public int Age { get; set; }
        public string Gender { get; set; } = null!;
    }
}
